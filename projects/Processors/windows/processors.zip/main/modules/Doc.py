import pygame

class Doc:
    def __init__(self):
        #self.surf = pygame.Surface()
        pass