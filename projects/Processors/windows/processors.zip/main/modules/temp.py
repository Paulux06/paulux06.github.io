from modules.tempHelp import *
def run():
    if isAppleNear():
        yield 38
        forward()
        yield 39
    else:
        yield 40
        backward()
        yield 41
        turnLeft()
        yield 42
    return True